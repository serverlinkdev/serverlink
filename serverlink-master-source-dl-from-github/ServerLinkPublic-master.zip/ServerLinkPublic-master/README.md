# ServerLinkPublic
UT2004 TAM/CW ServerLink

Check [service/install.sh](service/install.sh) for example installation/build.
