#!/bin/sh
java -jar /usr/local/share/ServerLink/serverlink.jar /opt/ServerLink/ServerLink.ini
