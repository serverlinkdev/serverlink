package org.uigl.ut2004.serverlink.exception;

public class ServerProtocolException extends Exception {
}
