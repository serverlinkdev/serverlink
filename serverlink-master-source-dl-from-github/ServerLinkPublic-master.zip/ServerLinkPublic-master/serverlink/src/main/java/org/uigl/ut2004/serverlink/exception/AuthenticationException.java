package org.uigl.ut2004.serverlink.exception;

public class AuthenticationException extends Exception {

}
